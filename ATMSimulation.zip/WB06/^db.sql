/*
SQLyog Community v8.71 
MySQL - 5.5.30 : Database - mjwb06
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mjwb06` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mjwb06`;

/*Table structure for table `bank_accounts` */

DROP TABLE IF EXISTS `bank_accounts`;

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `aadhar` varchar(12) NOT NULL,
  `account_type` enum('Savings','Current') NOT NULL,
  `balance` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `aadhar` (`aadhar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `bank_accounts` */

/*Table structure for table `credit` */

DROP TABLE IF EXISTS `credit`;

CREATE TABLE `credit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `FatherName` varchar(100) DEFAULT NULL,
  `AadharNumber` varchar(16) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `AtmNumber` varchar(16) NOT NULL,
  `AccountNumber` varchar(20) NOT NULL,
  `balance` int(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `AadharNumber` (`AadharNumber`),
  UNIQUE KEY `AtmNumber` (`AtmNumber`),
  UNIQUE KEY `AccountNumber` (`AccountNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `credit` */

insert  into `credit`(`id`,`Name`,`Email`,`FatherName`,`AadharNumber`,`Mobile`,`AtmNumber`,`AccountNumber`,`balance`,`CreatedAt`) values (1,'Un2','Un2@gmail.com','rajappa','123456789012','9977665544','4567789423457126','249496292438',277,'2025-04-03 14:09:48');

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `Name` varchar(1000) DEFAULT NULL,
  `Email` varchar(1000) DEFAULT NULL,
  `Father_Name` varchar(1000) DEFAULT NULL,
  `Aadhar` varchar(10000) DEFAULT NULL,
  `mobile` varchar(1000) DEFAULT NULL,
  `gender` varchar(1000) DEFAULT NULL,
  `Dob` varchar(1000) DEFAULT NULL,
  `Mop` varchar(1000) DEFAULT NULL,
  `Address` varchar(1000) DEFAULT NULL,
  `ATMCard` varchar(1000) DEFAULT NULL,
  `Ifscode` varchar(1000) DEFAULT NULL,
  `Account_No` varchar(10000) DEFAULT NULL,
  `Account_Created` varchar(10000) DEFAULT NULL,
  `user-hash` varchar(10000) DEFAULT NULL,
  `AtmPin` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`Name`,`Email`,`Father_Name`,`Aadhar`,`mobile`,`gender`,`Dob`,`Mop`,`Address`,`ATMCard`,`Ifscode`,`Account_No`,`Account_Created`,`user-hash`,`AtmPin`) values ('Un2','Un2@gmail.com','rajappa','123456789012','9977665544','male','2025-04-07','single','hyderabad 90-1-1234','4567789423457126','ADMIN11537','249496292438','2025-04-03 11:31:23','4dd35cc20b993f5bad9c764a8d7229eef3bb62ebb890f02a06a7ffde93583c1c','2345');

/*Table structure for table `debit` */

DROP TABLE IF EXISTS `debit`;

CREATE TABLE `debit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `FatherName` varchar(100) DEFAULT NULL,
  `AadharNumber` varchar(16) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `AtmNumber` varchar(16) NOT NULL,
  `AccountNumber` varchar(20) NOT NULL,
  `balance` int(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `AadharNumber` (`AadharNumber`),
  UNIQUE KEY `AtmNumber` (`AtmNumber`),
  UNIQUE KEY `AccountNumber` (`AccountNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `debit` */

/*Table structure for table `statement` */

DROP TABLE IF EXISTS `statement`;

CREATE TABLE `statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `FatherName` varchar(100) DEFAULT NULL,
  `AadharNumber` varchar(16) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `AtmNumber` varchar(16) NOT NULL,
  `AccountNumber` varchar(20) NOT NULL,
  `balance` int(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `AadharNumber` (`AadharNumber`),
  UNIQUE KEY `AtmNumber` (`AtmNumber`),
  UNIQUE KEY `AccountNumber` (`AccountNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `statement` */

insert  into `statement`(`id`,`Name`,`Email`,`FatherName`,`AadharNumber`,`Mobile`,`AtmNumber`,`AccountNumber`,`balance`,`CreatedAt`) values (1,'Un2','Un2@gmail.com','rajappa','123456789012','9977665544','4567789423457126','249496292438',654,'2025-04-03 14:31:11');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
