package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Database;

/**
 * Servlet implementation class Debit
 */
@WebServlet("/Debit")
public class Debit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Debit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		HttpSession session=request.getSession();
		String custpmer=(String)session.getAttribute("customer");
		
		String name = request.getParameter("name");
        String email = request.getParameter("email");
        String fname = request.getParameter("fname");
        String aadhar = request.getParameter("aadhar");
        String mobile = request.getParameter("mobile");
        String atmNumber = request.getParameter("atmNumber");
        String accountNumber = request.getParameter("accountNumber");
        int credit = Integer.parseInt(request.getParameter("credit")); 
	
        LocalDateTime currentDateTime = LocalDateTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	    String formattedDate = currentDateTime.format(formatter);
	    
        
        
        
	    Connection con = null;
        PreparedStatement ps = null;

        try {
        	
        	String sql="select balance from credit where Email='"+custpmer+"'";
			
			 con=Database.getConnection();
			 ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()) {
				int amount=rs.getInt(1);
				int balance=amount-credit;
				System.out.println(balance);
				sql="update debit set balance='"+balance+"' where Email='"+custpmer+"'";
				ps=con.prepareStatement(sql);
				int j=ps.executeUpdate();
				if(j>0) {
					System.out.println("-----------------------------------------------------");
					con = Database.getConnection();
		             sql = "INSERT INTO statement  VALUES (0,?, ?, ?, ?, ?, ?, ?, ?, ?)";
		            ps = con.prepareStatement(sql);
		            ps.setString(1, name);
		            ps.setString(2, email);
		            ps.setString(3, fname);
		            ps.setString(4, aadhar);
		            ps.setString(5, mobile);
		            ps.setString(6, atmNumber);
		            ps.setString(7, accountNumber);
		            ps.setInt(8, credit);  // Encrypt before storing
		            ps.setString(9, formattedDate);

		            int rowsInserted = ps.executeUpdate();
					
				}
				response.sendRedirect("chome.jsp");
			}
			else {
        	
        	
            con = Database.getConnection();
             sql = "INSERT INTO debit  VALUES (0,?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, fname);
            ps.setString(4, aadhar);
            ps.setString(5, mobile);
            ps.setString(6, atmNumber);
            ps.setString(7, accountNumber);
            ps.setInt(8, credit);  // Encrypt before storing
            ps.setString(9, formattedDate);

            int rowsInserted = ps.executeUpdate();
            if (rowsInserted > 0) {
            	
            	
            	
            	
                response.sendRedirect("chome.jsp");
            } else {
                //session.setAttribute("message", "Failed to store customer data.");
            }
			}
            //response.sendRedirect("profile.jsp"); // Redirect to profile page

        } catch (Exception e) {
            e.printStackTrace();
            
           // response.sendRedirect("profile.jsp");
        } finally {
            try { if (ps != null) ps.close(); if (con != null) con.close(); } catch (Exception e) { e.printStackTrace(); }
        }
	}

}
