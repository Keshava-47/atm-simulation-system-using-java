package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Hash;
import com.bean.User;
import com.dao.Database;

/**
 * Servlet implementation class BankRegister
 */
@WebServlet("/CustomerRegister")
public class BankRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public BankRegister() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uname=request.getParameter("name");
		String email=request.getParameter("email");
		String fname=request.getParameter("fname");
		String adhar=request.getParameter("ano");
		String mobile=request.getParameter("mobile");
		String gender=request.getParameter("gender");
		String dob=request.getParameter("dob");
		String marraige=request.getParameter("mop");
		String address=request.getParameter("address");
		String card=request.getParameter("card");
		
User u=new User();
	    
	    u.setUname(uname);
	    u.setEmail(email);
	    u.setFname(fname);
	    u.setAadhar(adhar);
	    u.setMobile(mobile);
	    u.setGender(gender);
	    u.setDob(dob);
	    u.setMop(marraige);
	    u.setAddress(address);
	    u.setBank(card);
		
		PrintWriter o=response.getWriter();
		LocalDateTime currentDateTime = LocalDateTime.now();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	    String formattedDate = currentDateTime.format(formatter);
	    try {
	    	String hashvalue=Hash.hashString(email, "SHA-256");
			int i=Database.Register(u, formattedDate,hashvalue);
			if(i>0) {
				o.println("<script type=\"text/javascript\">");
				o.println("alert(' Logined Successfully...');");
				o.println("window.location='clogin.jsp';</script>");
			}
			else {
				o.println("<script type=\"text/javascript\">");
				o.println("alert(' Registeration failed...');");
				o.println("window.location='Bankform.jsp';</script>");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	
	
	}

}
