package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Database;

/**
 * Servlet implementation class Pin
 */
@WebServlet("/pin")
public class Pin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Pin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter o=response.getWriter();
		int amount=Integer.parseInt(request.getParameter("amount")) ;
		//request.setAttribute("amount", amount);
		String account=request.getParameter("account");
		try {
	Connection con=Database.getConnection();
	String sql="select balance from credit where AccountNumber='"+account+"'";
	PreparedStatement ps=con.prepareStatement(sql);
	ResultSet rs=ps.executeQuery();
	if(rs.next()) {
		
		int balance=rs.getInt(1);
		if(balance>amount) {
			int pb=balance-amount;
			sql="update credit set balance='"+pb+"' where AccountNumber='"+account+"' ";
			ps=con.prepareStatement(sql);
			ps.executeUpdate();
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' Amount debited Successfully...');");
			o.println("</script>");
		
		}else {
				o.println("<script type=\"text/javascript\">");
				o.println("alert(' Insufficient Balance...');");
				o.println("</script>");
			
			}
			
		response.sendRedirect("pinverify.jsp");
		
	}else {
		response.sendRedirect("enterpin.jsp");
	}
	
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
	}

}
